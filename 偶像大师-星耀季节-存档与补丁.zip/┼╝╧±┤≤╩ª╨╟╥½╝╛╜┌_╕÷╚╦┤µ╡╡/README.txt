存档位置：
C:/Users/Aaron/AppData/Local/StarlitSeason/Saved/SaveGames